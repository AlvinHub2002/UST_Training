package com.example.customer_service.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class CustomerEntity {

    @Id
    private int cutomerId;
    private String customerName;
    private int movieId;

    public CustomerEntity() {
    }

    public CustomerEntity(int cutomerId, String customerName, int movieId) {
        this.cutomerId = cutomerId;
        this.customerName = customerName;
        this.movieId = movieId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCutomerId() {
        return cutomerId;
    }

    public void setCutomerId(int cutomerId) {
        this.cutomerId = cutomerId;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }
}
