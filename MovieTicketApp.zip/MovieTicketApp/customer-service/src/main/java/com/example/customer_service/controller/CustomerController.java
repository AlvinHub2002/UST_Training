package com.example.customer_service.controller;

import com.example.customer_service.entity.CustomerEntity;
import com.example.customer_service.model.CustomerPojo;
import com.example.customer_service.repository.CustomerRepository;
import com.example.customer_service.service.CustomerService;
import com.netflix.discovery.converters.Auto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class CustomerController {

    @Autowired
    CustomerService customerService;

    @Autowired
    CustomerRepository customerRepository;


    @GetMapping("/customers")
    public List<CustomerPojo> getAllCustomers(){
        return customerService.getAllCustomers();
    }

    @RequestMapping("/customers/{cusId}")
    public CustomerPojo getById(@PathVariable int cusId){
        return customerService.getCustomerById(cusId);
    }

    @PostMapping("/customers")
    public CustomerEntity addCustomer(@RequestBody CustomerEntity cus){
        return customerService.addCustomer(cus);
    }


    @GetMapping("/customers/movies/{mid}")
    public List<CustomerEntity>getAllCustomersByMovie(@PathVariable int mid){
     return customerRepository.findByMovieId(mid);
    }

}
