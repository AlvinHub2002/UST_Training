package com.example.customer_service.model;

public class CustomerPojo {

    private int custId;
    private String custName;
    private int movieId;

    public CustomerPojo() {
    }

    public CustomerPojo(int custId, String custName, int movieId) {
        this.custId = custId;
        this.custName = custName;
       this. movieId = movieId;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }
}
