package com.example.customer_service.service;

import com.example.customer_service.entity.CustomerEntity;
import com.example.customer_service.model.CustomerPojo;
import com.example.customer_service.repository.CustomerRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    CustomerRepository repo;

    public List<CustomerPojo> getAllCustomers(){
        List<CustomerEntity> allCustomer = repo.findAll();
        List<CustomerPojo> allCustomerPojo = new ArrayList<>();
        allCustomer.stream().forEach(EachCustomerEntity ->{
            CustomerPojo customerPojo = new CustomerPojo();
            BeanUtils.copyProperties(EachCustomerEntity,customerPojo);
            allCustomerPojo.add(customerPojo);

        });
        return allCustomerPojo;
    }

    public CustomerPojo getCustomerById(int cusId){
        Optional<CustomerEntity> custById = repo.findById(cusId);
        CustomerPojo cus =null;
        if(custById.isPresent()){
            cus = new CustomerPojo();
            BeanUtils.copyProperties(custById.get(),cus);
        }
        return cus;
    }

    public  CustomerEntity addCustomer(CustomerEntity customer){
       CustomerEntity cus = new CustomerEntity();
       BeanUtils.copyProperties(customer,cus);
       repo.saveAndFlush(cus);
       return cus;
    }

}
