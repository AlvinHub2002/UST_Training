package com.example.movie_service.controller;

import com.example.movie_service.entity.MovieEntity;
import com.example.movie_service.model.CustomerPojo;
import com.example.movie_service.model.MoviePojo;
import com.example.movie_service.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@RestController
@RequestMapping("/api")
public class MovieController {

    private final WebClient.Builder webClientBuilder;

    @Autowired
    public MovieController(MovieService movieService, WebClient.Builder webClientBuilder) {
        this.movieService = movieService;
        this.webClientBuilder = webClientBuilder;
    }

    @Autowired
    MovieService movieService;

    @GetMapping("/movies")
    public List<MoviePojo> getAllMovies(){
        return movieService.getAllMovies();
    }

    @GetMapping("/movies/{id}")
    public MoviePojo getById(@PathVariable int id) {
        MoviePojo moviePojo = movieService.getMovie(id);
        WebClient webClient = webClientBuilder.build();

        List<CustomerPojo> allCustomers = webClient.get()
                .uri("http://localhost:8081/api/customers/movies/" + id)
                .retrieve()
                .bodyToMono(List.class)
                .block(); // Blocking to get the result synchronously

        moviePojo.setAllCustomers(allCustomers);
        return moviePojo;
    }

    @PostMapping("/movies")
    public MovieEntity addMovie(@RequestBody MoviePojo newMovie){
        return movieService.addMovie(newMovie);
    }


}
