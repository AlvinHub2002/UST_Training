package com.example.movie_service.service;

import com.example.movie_service.entity.MovieEntity;
import com.example.movie_service.model.MoviePojo;
import com.example.movie_service.repository.MovieRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MovieService {

    @Autowired
    MovieRepository movieRepository;

    public List<MoviePojo> getAllMovies(){
        List<MovieEntity> allMovies = movieRepository.findAll();
        List<MoviePojo> allMoviePojo = new ArrayList<>();
        allMovies.stream().forEach((EachMovieEntity ->{
            MoviePojo moviePojo =new MoviePojo();
            BeanUtils.copyProperties(EachMovieEntity,moviePojo);
            allMoviePojo.add(moviePojo);
        }));
        return allMoviePojo;
    }

    public MoviePojo getMovie(int id){
        Optional<MovieEntity> movieById = movieRepository.findById(id);
        MoviePojo movie = null;
        if(movieById.isPresent()){
            movie=new MoviePojo();
            BeanUtils.copyProperties(movieById.get(),movie);
        }
        return movie;
    }

    public MovieEntity addMovie(MoviePojo newMovie){
        MovieEntity movie = new MovieEntity();
        BeanUtils.copyProperties(newMovie,movie);
        movieRepository.saveAndFlush(movie);
        return movie;
    }
}
